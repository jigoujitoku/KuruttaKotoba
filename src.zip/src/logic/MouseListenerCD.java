package logic;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

import gui.Board;

public class MouseListenerCD implements ActionListener {

	JButton label;
	JPanel panel;
	JPanel grid;
	int counter = 0;
	public static ArrayList<String> chosenSlova = new ArrayList<String>();
	static String string;
	public static boolean erase;

	public MouseListenerCD(JButton label, JPanel panel, JPanel grid) {
		this.label = label;
		this.panel = panel;
		this.grid = grid;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (counter) {
		case 0:
			// label.setBackground(new Color(102, 255, 102));
			panel.setBackground(new Color(102, 255, 102));
			chosenSlova.add(label.getText());
			SaveLetters.saveWord();
			break;
		case 1:
			label.setBackground(null);
			// label.setBorder(null);
			panel.setBackground(Color.white);
			counter = -1;
			chosenSlova.remove(label.getText());
			break;
		}
		counter++;
		Board.check.setText("Unos: " + (getWord()));

	}

	public static String getWord() {
		String word = "";
		for (String s : chosenSlova) {
			word += s;
		}
		word.toLowerCase();
		return word;
	}

}
