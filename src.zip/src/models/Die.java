package models;

public class Die {

}
